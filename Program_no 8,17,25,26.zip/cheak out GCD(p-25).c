#include<stdio.h> ///header file
void main()  ///main function
{
    int a,b,x; /// variable declare
    printf("Enter two integer numbers: "); ///print this value
    scanf("%d %d",&a ,&b); ///user input

    if(a<b) ///a=5,b=6
        x=a; ///assign value if condition satisfied
    else  x=b; /// if not satisfied then assign the value b
    apple: if(a%x==0 && b%x==0) ///if satisfied this then the value of x is GCD
    printf("the GCD of %d and %d is %d",a,b,x ); ///print  the GCD
    else
        {x=x-1; ///decrease the value for satisfied "if" condition
    goto apple;} ///goto the "apple" for doing if

}
